/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.breakoutegypt.servlet.util;

import com.breakoutegypt.servlet.util.JsonMoveCommand;
import java.io.StringReader;
import javax.json.Json;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;

/**
 *
 * @author kevin
 */
public class MoveCommandDecoder implements Decoder.Text<JsonMoveCommand>{

    @Override
    public JsonMoveCommand decode(String jsonString) throws DecodeException {
        JsonObject jsonObject = Json.createReader(new StringReader(jsonString)).readObject();
        return new JsonMoveCommand(jsonObject);
    }

    @Override
    public boolean willDecode(String string) {
        try {
            Json.createReader(new StringReader(string)).readObject();
            return true;
        } catch (JsonException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public void init(EndpointConfig config) {
    }

    @Override
    public void destroy() {
    }
    
}
